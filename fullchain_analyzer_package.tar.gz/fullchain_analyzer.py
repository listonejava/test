#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SpringBoot + Vue 全链路静态分析工具
支持 Python 3.12+ (兼容 3.14)
用于数币工程等 SpringBoot+Vue 项目的架构分析和需求影响性分析

作者：资深架构师
功能：前端组件 -> API 请求 -> Controller -> Service -> Mapper -> Entity -> 数据库表 全链路分析
"""

import os
import re
import json
import argparse
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field, asdict
from collections import defaultdict
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


@dataclass
class ApiEndpoint:
    """API 端点信息"""
    method: str  # GET, POST, PUT, DELETE
    path: str
    controller_class: str
    controller_method: str
    file_path: str
    line_number: int


@dataclass
class ServiceInfo:
    """Service 层信息"""
    class_name: str
    interface_name: Optional[str]
    methods: List[str]
    dependencies: List[str]  # 依赖的 Mapper/Repository
    file_path: str


@dataclass
class MapperInfo:
    """Mapper/Repository 层信息"""
    class_name: str
    interface_name: Optional[str]
    methods: List[str]
    entity_type: Optional[str]  # 关联的 Entity 类型
    xml_path: Optional[str]  # MyBatis XML 路径
    file_path: str


@dataclass
class EntityInfo:
    """Entity 实体类信息"""
    class_name: str
    table_name: str
    fields: List[Dict[str, Any]]
    primary_key: Optional[str]
    file_path: str


@dataclass
class VueComponent:
    """Vue 组件信息"""
    component_name: str
    file_path: str
    api_calls: List[Dict[str, Any]]  # API 调用列表
    functions: List[str]  # 组件函数
    imports: List[str]  # 导入的模块


@dataclass
class FullChain:
    """完整链路"""
    chain_id: str
    confidence: float  # 置信度 0-100
    vue_component: Optional[str]
    vue_function: Optional[str]
    api_method: Optional[str]
    api_path: Optional[str]
    controller_class: Optional[str]
    controller_method: Optional[str]
    service_class: Optional[str]
    service_method: Optional[str]
    mapper_class: Optional[str]
    mapper_method: Optional[str]
    entity_class: Optional[str]
    table_name: Optional[str]
    description: str


@dataclass
class DataSourceConfig:
    """数据源配置"""
    url: str
    username: str
    driver_class: str
    database: str


@dataclass
class AnalysisResult:
    """分析结果"""
    project_name: str
    analysis_time: str
    backend_path: str
    frontend_path: str
    data_source: Optional[DataSourceConfig]
    controllers: List[ApiEndpoint]
    services: List[ServiceInfo]
    mappers: List[MapperInfo]
    entities: List[EntityInfo]
    vue_components: List[VueComponent]
    full_chains: List[FullChain]
    statistics: Dict[str, int]


class JavaAnalyzer:
    """Java/SpringBoot 代码分析器"""
    
    # Spring MVC 注解映射
    HTTP_METHOD_ANNOTATIONS = {
        '@GetMapping': 'GET',
        '@PostMapping': 'POST',
        '@PutMapping': 'PUT',
        '@DeleteMapping': 'DELETE',
        '@PatchMapping': 'PATCH',
        '@RequestMapping': 'REQUEST'
    }
    
    def __init__(self, backend_path: str):
        self.backend_path = Path(backend_path)
        self.controllers: List[ApiEndpoint] = []
        self.services: List[ServiceInfo] = []
        self.mappers: List[MapperInfo] = []
        self.entities: List[EntityInfo] = []
        self.data_source: Optional[DataSourceConfig] = None
        
    def analyze(self) -> None:
        """执行完整分析"""
        logger.info("开始分析后端代码...")
        self._parse_config()
        self._find_controllers()
        self._find_services()
        self._find_mappers()
        self._find_entities()
        logger.info(f"后端分析完成: {len(self.controllers)} Controllers, "
                   f"{len(self.services)} Services, {len(self.mappers)} Mappers, "
                   f"{len(self.entities)} Entities")
    
    def _parse_config(self) -> None:
        """解析配置文件"""
        config_paths = [
            self.backend_path / 'src' / 'main' / 'resources' / 'application.properties',
            self.backend_path / 'src' / 'main' / 'resources' / 'application.yml',
            self.backend_path / 'src' / 'main' / 'resources' / 'application.yaml',
        ]
        
        for config_path in config_paths:
            if config_path.exists():
                logger.info(f"解析配置文件: {config_path}")
                self._parse_config_file(config_path)
                break
    
    def _parse_config_file(self, config_path: Path) -> None:
        """解析单个配置文件"""
        content = config_path.read_text(encoding='utf-8', errors='ignore')
        
        url = username = driver = database = None
        
        if config_path.suffix in ['.yml', '.yaml']:
            # 简单 YAML 解析
            for line in content.split('\n'):
                line = line.strip()
                if 'url:' in line and 'jdbc:' in line:
                    url = line.split(':', 1)[1].strip().strip('"\'')
                elif 'username:' in line:
                    username = line.split(':', 1)[1].strip().strip('"\'')
                elif 'driver-class-name:' in line or 'driverClassName:' in line:
                    driver = line.split(':', 1)[1].strip().strip('"\'')
        else:
            # Properties 解析
            for line in content.split('\n'):
                line = line.strip()
                if line.startswith('#') or '=' not in line:
                    continue
                key, value = line.split('=', 1)
                key = key.strip()
                value = value.strip()
                
                if 'url' in key and 'jdbc:' in value:
                    url = value
                elif 'username' in key:
                    username = value
                elif 'driver-class-name' in key or 'driverClassName' in key:
                    driver = value
        
        if url:
            # 提取数据库名
            db_match = re.search(r'/([^/?]+)', url)
            database = db_match.group(1) if db_match else 'unknown'
            
            self.data_source = DataSourceConfig(
                url=url,
                username=username or 'unknown',
                driver_class=driver or 'unknown',
                database=database
            )
            logger.info(f"数据源: {database} ({url})")
    
    def _find_controllers(self) -> None:
        """查找所有 Controller"""
        logger.info("扫描 Controllers...")
        
        for java_file in self.backend_path.rglob('*.java'):
            content = java_file.read_text(encoding='utf-8', errors='ignore')
            
            # 检查是否是 Controller
            if not ('@RestController' in content or '@Controller' in content):
                continue
            
            # 提取类名
            class_match = re.search(r'(?:public\s+)?class\s+(\w+)', content)
            if not class_match:
                continue
            class_name = class_match.group(1)
            
            # 提取类级别的 RequestMapping
            base_path = ''
            base_mapping = re.search(r'@(?:Request)?Mapping\s*\(\s*["\']([^"\']*)["\']', content)
            if base_mapping:
                base_path = base_mapping.group(1)
            
            # 查找所有方法级别的映射
            for annot, method_type in self.HTTP_METHOD_ANNOTATIONS.items():
                pattern = rf'{annot}(?:\s*\(\s*(?:value|path)\s*=\s*)?["\']([^"\']*)["\']'
                for match in re.finditer(pattern, content):
                    path = match.group(1)
                    
                    # 查找方法名
                    method_start = match.end()
                    method_match = re.search(rf'{annot}[^)]*\)\s*\w+\s+(\w+)\s*\(', 
                                            content[method_start-50:method_start+100])
                    if not method_match:
                        # 尝试另一种模式
                        lines = content[max(0, match.start()-200):match.end()+200].split('\n')
                        for i, line in enumerate(lines):
                            if annot in line or (i > 0 and match.group(0) in line):
                                method_search = re.search(r'\b(\w+)\s*\([^)]*\)\s*\{{0,1}', line)
                                if method_search:
                                    method_name = method_search.group(1)
                                    break
                        else:
                            method_name = 'unknown'
                    else:
                        method_name = method_match.group(1)
                    
                    # 组合路径
                    full_path = '/'.join([p.strip('/') for p in [base_path, path] if p])
                    if not full_path.startswith('/'):
                        full_path = '/' + full_path
                    
                    endpoint = ApiEndpoint(
                        method=method_type,
                        path=full_path,
                        controller_class=class_name,
                        controller_method=method_name,
                        file_path=str(java_file),
                        line_number=content[:match.start()].count('\n') + 1
                    )
                    self.controllers.append(endpoint)
        
        logger.info(f"找到 {len(self.controllers)} 个 API 端点")
    
    def _find_services(self) -> None:
        """查找所有 Service"""
        logger.info("扫描 Services...")
        
        for java_file in self.backend_path.rglob('*.java'):
            content = java_file.read_text(encoding='utf-8', errors='ignore')
            
            if '@Service' not in content and '@Transactional' not in content:
                continue
            
            # 提取类名
            class_match = re.search(r'(?:public\s+)?class\s+(\w+)', content)
            if not class_match:
                continue
            class_name = class_match.group(1)
            
            # 提取接口名
            interface_name = None
            impl_match = re.search(r'implements\s+(\w+)', content)
            if impl_match:
                interface_name = impl_match.group(1)
            
            # 提取方法
            methods = []
            method_pattern = r'(?:public|private|protected)\s+(?:\w+\s+)+(\w+)\s*\([^)]*\)'
            for match in re.finditer(method_pattern, content):
                method_name = match.group(1)
                if method_name not in ['toString', 'equals', 'hashCode', 'getClass']:
                    methods.append(method_name)
            
            # 提取依赖的 Mapper
            dependencies = []
            mapper_pattern = r'@(?:Autowired|Resource)\s*\n?\s*(?:private|\w+)\s+(\w+)\s+'
            for match in re.finditer(mapper_pattern, content):
                dep_name = match.group(1)
                if 'mapper' in dep_name.lower() or 'dao' in dep_name.lower() or 'repository' in dep_name.lower():
                    dependencies.append(dep_name)
            
            service = ServiceInfo(
                class_name=class_name,
                interface_name=interface_name,
                methods=methods,
                dependencies=list(set(dependencies)),
                file_path=str(java_file)
            )
            self.services.append(service)
        
        logger.info(f"找到 {len(self.services)} 个 Services")
    
    def _find_mappers(self) -> None:
        """查找所有 Mapper/Repository"""
        logger.info("扫描 Mappers...")
        
        for java_file in self.backend_path.rglob('*.java'):
            content = java_file.read_text(encoding='utf-8', errors='ignore')
            
            if '@Mapper' not in content and '@Repository' not in content:
                continue
            
            # 提取类名
            class_match = re.search(r'(?:public\s+)?(?:interface|class)\s+(\w+)', content)
            if not class_match:
                continue
            class_name = class_match.group(1)
            
            # 提取 Entity 类型
            entity_type = None
            entity_match = re.search(r'<(\w+)>', content)
            if entity_match:
                entity_type = entity_match.group(1)
            
            # 提取方法
            methods = []
            if 'interface' in content:
                method_pattern = r'\w+\s+(\w+)\s*\([^)]*\)'
                for match in re.finditer(method_pattern, content):
                    method_name = match.group(1)
                    if method_name not in ['equals', 'hashCode']:
                        methods.append(method_name)
            
            # 查找对应的 XML 文件
            xml_path = None
            xml_patterns = [
                java_file.with_suffix('.xml'),
                java_file.parent / f'{class_name}.xml',
                self.backend_path / 'src' / 'main' / 'resources' / 'mapper' / f'{class_name}.xml',
            ]
            for xp in xml_patterns:
                if xp.exists():
                    xml_path = str(xp)
                    break
            
            mapper = MapperInfo(
                class_name=class_name,
                interface_name=None,
                methods=methods,
                entity_type=entity_type,
                xml_path=xml_path,
                file_path=str(java_file)
            )
            self.mappers.append(mapper)
        
        logger.info(f"找到 {len(self.mappers)} 个 Mappers")
    
    def _find_entities(self) -> None:
        """查找所有 Entity"""
        logger.info("扫描 Entities...")
        
        for java_file in self.backend_path.rglob('*.java'):
            content = java_file.read_text(encoding='utf-8', errors='ignore')
            
            if '@Entity' not in content and '@Table' not in content:
                continue
            
            # 跳过非 entity 包
            if 'dto' in str(java_file).lower() or 'vo' in str(java_file).lower():
                continue
            
            # 提取类名
            class_match = re.search(r'(?:public\s+)?class\s+(\w+)', content)
            if not class_match:
                continue
            class_name = class_match.group(1)
            
            # 提取表名
            table_name = class_name.lower()
            table_match = re.search(r'@Table\s*\(\s*name\s*=\s*["\']([^"\']+)["\']', content)
            if table_match:
                table_name = table_match.group(1)
            
            # 提取字段
            fields = []
            field_pattern = r'@(?:Column\s*\([^)]*\)\s+)?(?:Id\s+)?(?:\w+\s+)+(\w+)\s*;'
            for match in re.finditer(field_pattern, content):
                field_name = match.group(1)
                field_info = {'name': field_name}
                
                # 检查是否为主键
                if '@Id' in content[max(0, match.start()-100):match.start()]:
                    field_info['primary_key'] = True
                
                fields.append(field_info)
            
            # 查找主键
            primary_key = None
            id_match = re.search(r'@Id\s+(?:\w+\s+)+(\w+)\s*;', content)
            if id_match:
                primary_key = id_match.group(1)
            elif fields:
                for f in fields:
                    if f.get('primary_key'):
                        primary_key = f['name']
                        break
            
            entity = EntityInfo(
                class_name=class_name,
                table_name=table_name,
                fields=fields,
                primary_key=primary_key,
                file_path=str(java_file)
            )
            self.entities.append(entity)
        
        logger.info(f"找到 {len(self.entities)} 个 Entities")


class VueAnalyzer:
    """Vue 前端代码分析器"""
    
    def __init__(self, frontend_path: str):
        self.frontend_path = Path(frontend_path)
        self.components: List[VueComponent] = []
        
    def analyze(self) -> None:
        """执行完整分析"""
        logger.info("开始分析前端代码...")
        self._find_components()
        logger.info(f"前端分析完成: {len(self.components)} 个 Vue 组件")
    
    def _find_components(self) -> None:
        """查找所有 Vue 组件"""
        logger.info("扫描 Vue 组件...")
        
        for vue_file in self.frontend_path.rglob('*.vue'):
            content = vue_file.read_text(encoding='utf-8', errors='ignore')
            
            # 提取组件名
            component_name = vue_file.stem
            
            # 提取导入
            imports = []
            import_pattern = r'import\s+\{?\s*[\w\s,]+\}?\s+from\s+[\'"]([^\'"]+)[\'"]'
            for match in re.finditer(import_pattern, content):
                imports.append(match.group(1))
            
            # 提取函数
            functions = []
            func_pattern = r'(?:async\s+)?(\w+)\s*\([^)]*\)\s*(?::\s*\w+)?\s*\{'
            for match in re.finditer(func_pattern, content):
                func_name = match.group(1)
                if func_name not in ['if', 'for', 'while', 'switch']:
                    functions.append(func_name)
            
            # 提取 API 调用
            api_calls = []
            
            # 直接 axios 调用
            axios_pattern = r'(?:axios|this\.\$axios|request)\.(get|post|put|delete|patch)\s*\(\s*[\'"]([^\'"]+)[\'"]'
            for match in re.finditer(axios_pattern, content, re.IGNORECASE):
                method = match.group(1).upper()
                path = match.group(2)
                api_calls.append({
                    'method': method,
                    'path': path,
                    'call_type': 'direct',
                    'line': content[:match.start()].count('\n') + 1
                })
            
            # API 模块调用 (如 api.getUserList())
            api_module_pattern = r'(\w+)\.(\w+)\s*\([^)]*\)'
            for match in re.finditer(api_module_pattern, content):
                module_name = match.group(1)
                method_name = match.group(2)
                if 'api' in module_name.lower() or 'service' in module_name.lower():
                    # 尝试推断 API 路径
                    inferred_path = self._infer_api_path(module_name, method_name, imports)
                    if inferred_path:
                        api_calls.append({
                            'method': 'GET',  # 默认，实际需要从 API 模块中解析
                            'path': inferred_path,
                            'call_type': 'module',
                            'module': module_name,
                            'method_name': method_name,
                            'line': content[:match.start()].count('\n') + 1
                        })
            
            component = VueComponent(
                component_name=component_name,
                file_path=str(vue_file),
                api_calls=api_calls,
                functions=functions,
                imports=imports
            )
            self.components.append(component)
    
    def _infer_api_path(self, module_name: str, method_name: str, imports: List[str]) -> Optional[str]:
        """根据模块名和方法名推断 API 路径"""
        # 常见映射规则
        resource_map = {
            'user': '/user',
            'order': '/order',
            'product': '/product',
            'role': '/role',
            'permission': '/permission',
            'menu': '/menu',
            'dept': '/dept',
            'dict': '/dict',
        }
        
        action_map = {
            'list': '/list',
            'get': '',
            'add': '',
            'create': '',
            'update': '',
            'edit': '',
            'delete': '',
            'remove': '',
            'info': '/info',
            'detail': '/detail',
        }
        
        # 从方法名中提取资源
        for resource, path in resource_map.items():
            if resource in method_name.lower():
                action = '/list'  # 默认
                for act, act_path in action_map.items():
                    if act in method_name.lower():
                        action = act_path
                        break
                return f'/api{path}{action}'
        
        return None


class ChainBuilder:
    """全链路构建器"""
    
    def __init__(self, java_analyzer: JavaAnalyzer, vue_analyzer: VueAnalyzer):
        self.java_analyzer = java_analyzer
        self.vue_analyzer = vue_analyzer
        self.chains: List[FullChain] = []
    
    def build_chains(self) -> List[FullChain]:
        """构建所有可能的链路"""
        logger.info("开始构建全链路...")
        
        # 建立索引
        api_index = {}  # path -> endpoints
        for ep in self.java_analyzer.controllers:
            key = f"{ep.method}:{ep.path}"
            if key not in api_index:
                api_index[key] = []
            api_index[key].append(ep)
        
        # 为每个 Vue 组件的 API 调用构建链路
        chain_id = 0
        for component in self.vue_analyzer.components:
            for api_call in component.api_calls:
                method = api_call.get('method', 'GET')
                path = api_call.get('path', '')
                
                if not path:
                    continue
                
                # 查找匹配的 Controller
                key = f"{method}:{path}"
                endpoints = api_index.get(key, [])
                
                # 也尝试模糊匹配
                if not endpoints:
                    for ep_key, ep_list in api_index.items():
                        ep_method, ep_path = ep_key.split(':', 1)
                        if ep_method == method and self._path_match(path, ep_path):
                            endpoints = ep_list
                            break
                
                if endpoints:
                    for endpoint in endpoints:
                        chain = self._build_chain(chain_id, component, api_call, endpoint)
                        self.chains.append(chain)
                        chain_id += 1
                else:
                    # 未找到匹配的 Controller，创建部分链路
                    chain = FullChain(
                        chain_id=f"CHAIN_{chain_id:04d}",
                        confidence=30.0,
                        vue_component=component.component_name,
                        vue_function=self._find_calling_function(component, api_call),
                        api_method=method,
                        api_path=path,
                        controller_class=None,
                        controller_method=None,
                        service_class=None,
                        service_method=None,
                        mapper_class=None,
                        mapper_method=None,
                        entity_class=None,
                        table_name=None,
                        description=f"前端调用 {method} {path}，未找到匹配的后端 Controller"
                    )
                    self.chains.append(chain)
                    chain_id += 1
        
        # 为没有前端调用的 Controller 也创建链路
        existing_paths = set()
        for component in self.vue_analyzer.components:
            for api_call in component.api_calls:
                existing_paths.add(api_call.get('path', ''))
        
        for endpoint in self.java_analyzer.controllers:
            if endpoint.path not in existing_paths:
                chain = self._build_backend_chain(chain_id, endpoint)
                self.chains.append(chain)
                chain_id += 1
        
        logger.info(f"构建完成 {len(self.chains)} 条链路")
        return self.chains
    
    def _path_match(self, path1: str, path2: str) -> bool:
        """模糊路径匹配"""
        # 移除尾部斜杠
        p1 = path1.rstrip('/')
        p2 = path2.rstrip('/')
        
        # 完全匹配
        if p1 == p2:
            return True
        
        # 包含匹配
        if p1 in p2 or p2 in p1:
            return True
        
        # 忽略 ID 参数的匹配
        p1_clean = re.sub(r'/\d+', '/{id}', p1)
        p2_clean = re.sub(r'/\d+', '/{id}', p2)
        if p1_clean == p2_clean:
            return True
        
        return False
    
    def _find_calling_function(self, component: VueComponent, api_call: Dict) -> Optional[str]:
        """查找调用 API 的函数"""
        line = api_call.get('line', 0)
        
        # 向前查找最近的函数定义
        content = Path(component.file_path).read_text(encoding='utf-8', errors='ignore')
        lines = content.split('\n')
        
        for i in range(line - 1, max(0, line - 50), -1):
            if i < len(lines):
                func_match = re.search(r'(?:async\s+)?(\w+)\s*\([^)]*\)', lines[i])
                if func_match:
                    func_name = func_match.group(1)
                    if func_name in component.functions:
                        return func_name
        
        return None
    
    def _build_chain(self, chain_id: int, component: VueComponent, 
                     api_call: Dict, endpoint: ApiEndpoint) -> FullChain:
        """构建完整链路"""
        confidence = 100.0
        description_parts = []
        
        # 查找关联的 Service
        service_class = None
        service_method = None
        for service in self.java_analyzer.services:
            if endpoint.controller_class.replace('Controller', 'Service') == service.class_name:
                service_class = service.class_name
                service_method = endpoint.controller_method
                description_parts.append(f"Service: {service_class}")
                break
        
        # 查找关联的 Mapper
        mapper_class = None
        mapper_method = None
        for mapper in self.java_analyzer.mappers:
            if service_class:
                for dep in self.java_analyzer.services:
                    if dep.class_name == service_class and mapper.class_name.lower() in [d.lower() for d in dep.dependencies]:
                        mapper_class = mapper.class_name
                        mapper_method = endpoint.controller_method
                        description_parts.append(f"Mapper: {mapper_class}")
                        break
        
        # 查找关联的 Entity
        entity_class = None
        table_name = None
        for entity in self.java_analyzer.entities:
            if mapper_class:
                if entity.class_name.lower() == mapper_class.replace('Mapper', '').lower():
                    entity_class = entity.class_name
                    table_name = entity.table_name
                    description_parts.append(f"Entity: {entity_class} -> Table: {table_name}")
                    break
        
        # 计算置信度
        confidence = 50.0
        if endpoint:
            confidence += 20
        if service_class:
            confidence += 10
        if mapper_class:
            confidence += 10
        if entity_class:
            confidence += 10
        
        confidence = min(confidence, 100.0)
        
        calling_func = self._find_calling_function(component, api_call)
        
        return FullChain(
            chain_id=f"CHAIN_{chain_id:04d}",
            confidence=confidence,
            vue_component=component.component_name,
            vue_function=calling_func,
            api_method=api_call.get('method'),
            api_path=api_call.get('path'),
            controller_class=endpoint.controller_class,
            controller_method=endpoint.controller_method,
            service_class=service_class,
            service_method=service_method,
            mapper_class=mapper_class,
            mapper_method=mapper_method,
            entity_class=entity_class,
            table_name=table_name,
            description=" | ".join(description_parts) if description_parts else "后端链路待完善"
        )
    
    def _build_backend_chain(self, chain_id: int, endpoint: ApiEndpoint) -> FullChain:
        """仅为后端构建链路（无前端调用）"""
        return FullChain(
            chain_id=f"CHAIN_{chain_id:04d}",
            confidence=40.0,
            vue_component=None,
            vue_function=None,
            api_method=endpoint.method,
            api_path=endpoint.path,
            controller_class=endpoint.controller_class,
            controller_method=endpoint.controller_method,
            service_class=None,
            service_method=None,
            mapper_class=None,
            mapper_method=None,
            entity_class=None,
            table_name=None,
            description=f"后端 API {endpoint.method} {endpoint.path}，暂未发现前端调用"
        )


class ReportGenerator:
    """报告生成器"""
    
    def __init__(self, result: AnalysisResult):
        self.result = result
    
    def generate_json(self, output_path: str) -> None:
        """生成 JSON 报告"""
        data = asdict(self.result)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"JSON 报告已生成: {output_path}")
    
    def generate_markdown(self, output_path: str) -> None:
        """生成 Markdown 报告"""
        md_lines = []
        
        # 标题
        md_lines.append(f"# {self.result.project_name} - 全链路静态分析报告\n")
        md_lines.append(f"**生成时间**: {self.result.analysis_time}\n")
        md_lines.append(f"**后端路径**: {self.result.backend_path}\n")
        md_lines.append(f"**前端路径**: {self.result.frontend_path}\n")
        md_lines.append("---\n")
        
        # 统计概览
        md_lines.append("## 📊 统计概览\n")
        stats = self.result.statistics
        md_lines.append(f"- **Controllers**: {stats.get('controllers', 0)}")
        md_lines.append(f"- **Services**: {stats.get('services', 0)}")
        md_lines.append(f"- **Mappers**: {stats.get('mappers', 0)}")
        md_lines.append(f"- **Entities**: {stats.get('entities', 0)}")
        md_lines.append(f"- **Vue Components**: {stats.get('vue_components', 0)}")
        md_lines.append(f"- **Full Chains**: {stats.get('full_chains', 0)}\n")
        
        # 数据源配置
        if self.result.data_source:
            md_lines.append("## 🗄️ 数据源配置\n")
            ds = self.result.data_source
            md_lines.append(f"- **数据库**: {ds.database}")
            md_lines.append(f"- **URL**: `{ds.url}`")
            md_lines.append(f"- **用户名**: {ds.username}")
            md_lines.append(f"- **驱动**: {ds.driver_class}\n")
        
        # 全链路追踪
        md_lines.append("## 🔗 全链路追踪\n")
        for chain in self.result.full_chains[:20]:  # 限制显示数量
            confidence_emoji = "✅" if chain.confidence >= 70 else "⚠️" if chain.confidence >= 50 else "❓"
            md_lines.append(f"### {confidence_emoji} {chain.chain_id} (置信度: {chain.confidence:.1f}%)\n")
            
            if chain.vue_component:
                md_lines.append(f"- **前端组件**: `{chain.vue_component}.vue`")
                if chain.vue_function:
                    md_lines.append(f"  - 函数: `{chain.vue_function}()`")
            
            if chain.api_path:
                md_lines.append(f"- **API**: `{chain.api_method} {chain.api_path}`")
            
            if chain.controller_class:
                md_lines.append(f"- **Controller**: `{chain.controller_class}.{chain.controller_method}()`")
            
            if chain.service_class:
                md_lines.append(f"- **Service**: `{chain.service_class}.{chain.service_method}()`")
            
            if chain.mapper_class:
                md_lines.append(f"- **Mapper**: `{chain.mapper_class}.{chain.mapper_method}()`")
            
            if chain.entity_class:
                md_lines.append(f"- **Entity**: `{chain.entity_class}` → **表**: `{chain.table_name}`")
            
            md_lines.append(f"- **描述**: {chain.description}\n")
        
        if len(self.result.full_chains) > 20:
            md_lines.append(f"\n> 共 {len(self.result.full_chains)} 条链路，此处仅显示前 20 条。详见 JSON 文件。\n")
        
        # Controllers 列表
        md_lines.append("## 🎮 Controllers\n")
        for ctrl in self.result.controllers[:10]:
            md_lines.append(f"- `{ctrl.method} {ctrl.path}` → `{ctrl.controller_class}.{ctrl.controller_method}()`")
        if len(self.result.controllers) > 10:
            md_lines.append(f"\n> 共 {len(self.result.controllers)} 个端点，此处仅显示前 10 个。\n")
        
        # Services 列表
        md_lines.append("\n## ⚙️ Services\n")
        for svc in self.result.services[:10]:
            deps = ', '.join(svc.dependencies) if svc.dependencies else '无'
            md_lines.append(f"- `{svc.class_name}` (接口: {svc.interface_name or '无'}, 依赖: {deps})")
        
        # Entities 列表
        md_lines.append("\n## 📦 Entities\n")
        for ent in self.result.entities[:10]:
            pk = f" (PK: {ent.primary_key})" if ent.primary_key else ""
            md_lines.append(f"- `{ent.class_name}` → 表 `{ent.table_name}`{pk}")
        
        # Vue Components 列表
        md_lines.append("\n## 🖥️ Vue Components\n")
        for comp in self.result.vue_components[:10]:
            api_count = len(comp.api_calls)
            md_lines.append(f"- `{comp.component_name}.vue` (API 调用: {api_count}, 函数: {len(comp.functions)})")
        
        # 需求影响性分析指南
        md_lines.append("\n---\n")
        md_lines.append("## 📈 需求影响性分析指南\n")
        md_lines.append("""
### 1. 前端变更影响分析
当需要修改某个 Vue 组件时：
1. 在"全链路追踪"中查找该组件
2. 查看其调用的 API 端点
3. 追溯到对应的 Controller、Service、Mapper
4. 评估后端代码是否需要相应调整

### 2. 后端变更影响分析
当需要修改后端代码时：
- **修改 Service**: 查看哪些 Controller 调用该 Service，进而影响哪些前端组件
- **修改 Mapper**: 查看哪些 Service 依赖该 Mapper，向上追溯影响范围
- **修改 Entity/表结构**: 查看哪些 Mapper 使用该 Entity，向上追溯完整链路

### 3. 数据库变更影响分析
当需要修改数据库表结构时：
1. 在"Entities"中找到对应表的实体类
2. 查看哪些 Mapper 操作该实体
3. 追溯受影响的 Service 和 Controller
4. 确认前端是否有相关调用

### 4. 增量开发辅助
新增功能时参考现有链路模式：
1. **前端**: 参考现有 Vue 组件的 API 调用方式
2. **Controller**: 参考现有端点的命名和结构
3. **Service**: 参考业务逻辑分层模式
4. **Mapper**: 参考数据访问层实现
5. **Entity**: 参考实体类与表的映射关系

### 5. 置信度说明
- ✅ **高置信度 (≥70%)**: 链路完整，前后端匹配度高
- ⚠️ **中置信度 (50%-70%)**: 链路基本完整，部分环节为推断
- ❓ **低置信度 (<50%)**: 链路不完整或为推测，需人工确认
""")
        
        # 写入文件
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(md_lines))
        
        logger.info(f"Markdown 报告已生成: {output_path}")


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description='SpringBoot + Vue 全链路静态分析工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  python fullchain_analyzer.py --backend ./springboot-project --frontend ./vue-project
  python fullchain_analyzer.py -b E:/project/backend -f E:/project/frontend -o E:/analysis_output --format both
  python fullchain_analyzer.py --backend ./backend --frontend ./frontend --project-name "数币工程"
        """
    )
    
    parser.add_argument('--backend', '-b', required=True, help='SpringBoot 后端项目路径')
    parser.add_argument('--frontend', '-f', required=True, help='Vue 前端项目路径')
    parser.add_argument('--output', '-o', default='./analysis_output', help='输出目录 (默认: ./analysis_output)')
    parser.add_argument('--format', choices=['json', 'md', 'both'], default='both', help='输出格式 (默认: both)')
    parser.add_argument('--project-name', '-p', default='未命名项目', help='项目名称')
    
    args = parser.parse_args()
    
    # 验证路径
    backend_path = Path(args.backend)
    frontend_path = Path(args.frontend)
    
    if not backend_path.exists():
        logger.error(f"后端路径不存在: {backend_path}")
        return 1
    
    if not frontend_path.exists():
        logger.error(f"前端路径不存在: {frontend_path}")
        return 1
    
    # 创建输出目录
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 生成时间戳
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # 执行分析
    logger.info(f"开始分析项目: {args.project_name}")
    logger.info(f"后端: {backend_path}")
    logger.info(f"前端: {frontend_path}")
    
    # 后端分析
    java_analyzer = JavaAnalyzer(str(backend_path))
    java_analyzer.analyze()
    
    # 前端分析
    vue_analyzer = VueAnalyzer(str(frontend_path))
    vue_analyzer.analyze()
    
    # 构建链路
    chain_builder = ChainBuilder(java_analyzer, vue_analyzer)
    chains = chain_builder.build_chains()
    
    # 构建结果
    statistics = {
        'controllers': len(java_analyzer.controllers),
        'services': len(java_analyzer.services),
        'mappers': len(java_analyzer.mappers),
        'entities': len(java_analyzer.entities),
        'vue_components': len(vue_analyzer.components),
        'full_chains': len(chains)
    }
    
    result = AnalysisResult(
        project_name=args.project_name,
        analysis_time=datetime.now().isoformat(),
        backend_path=str(backend_path),
        frontend_path=str(frontend_path),
        data_source=java_analyzer.data_source,
        controllers=java_analyzer.controllers,
        services=java_analyzer.services,
        mappers=java_analyzer.mappers,
        entities=java_analyzer.entities,
        vue_components=vue_analyzer.components,
        full_chains=chains,
        statistics=statistics
    )
    
    # 生成报告
    generator = ReportGenerator(result)
    
    if args.format in ['json', 'both']:
        json_path = output_dir / f'fullchain_analysis_{timestamp}.json'
        generator.generate_json(str(json_path))
    
    if args.format in ['md', 'both']:
        md_path = output_dir / f'fullchain_analysis_{timestamp}.md'
        generator.generate_markdown(str(md_path))
    
    logger.info("=" * 60)
    logger.info("分析完成!")
    logger.info(f"统计: {statistics}")
    logger.info(f"报告输出目录: {output_dir}")
    logger.info("=" * 60)
    
    return 0


if __name__ == '__main__':
    exit(main())
