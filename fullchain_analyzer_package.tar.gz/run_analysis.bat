@echo off
REM ============================================================
REM SpringBoot + Vue 全链路静态分析工具 - Windows 批处理启动脚本
REM ============================================================

REM 配置区域 - 请根据实际情况修改以下路径
SET BACKEND_PATH=E:\workspace-analysis\AI4DC\05 源码\backend
SET FRONTEND_PATH=E:\workspace-analysis\AI4DC\05 源码\frontend
SET OUTPUT_PATH=E:\workspace-analysis\AI4DC\05 源码\analysis_output
SET PROJECT_NAME=数币工程
SET TOOL_PATH=E:\tools\fullchain_analyzer.py

REM ============================================================
REM 检查 Python 环境
REM ============================================================
echo ========================================
echo SpringBoot + Vue 全链路静态分析工具
echo ========================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未找到 Python，请确认已安装 Python 3.12+
    echo 下载地址：https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [信息] Python 环境检查通过
python --version
echo.

REM ============================================================
REM 检查工具文件是否存在
REM ============================================================
if not exist "%TOOL_PATH%" (
    echo [错误] 未找到分析工具：%TOOL_PATH%
    echo 请将 fullchain_analyzer.py 放置到该路径
    pause
    exit /b 1
)

echo [信息] 工具文件存在：%TOOL_PATH%
echo.

REM ============================================================
REM 检查后端目录
REM ============================================================
if not exist "%BACKEND_PATH%" (
    echo [警告] 后端目录不存在：%BACKEND_PATH%
    echo 请修改批处理文件中的 BACKEND_PATH 变量
    pause
    exit /b 1
)

echo [信息] 后端目录：%BACKEND_PATH%
echo.

REM ============================================================
REM 检查前端目录
REM ============================================================
if not exist "%FRONTEND_PATH%" (
    echo [警告] 前端目录不存在：%FRONTEND_PATH%
    echo 请修改批处理文件中的 FRONTEND_PATH 变量
    pause
    exit /b 1
)

echo [信息] 前端目录：%FRONTEND_PATH%
echo.

REM ============================================================
REM 创建输出目录
REM ============================================================
if not exist "%OUTPUT_PATH%" (
    echo [信息] 创建输出目录：%OUTPUT_PATH%
    mkdir "%OUTPUT_PATH%"
)

echo [信息] 输出目录：%OUTPUT_PATH%
echo.

REM ============================================================
REM 执行分析
REM ============================================================
echo ========================================
echo 开始分析项目：%PROJECT_NAME%
echo ========================================
echo.

python "%TOOL_PATH%" ^
  --backend "%BACKEND_PATH%" ^
  --frontend "%FRONTEND_PATH%" ^
  --output "%OUTPUT_PATH%" ^
  --project-name "%PROJECT_NAME%" ^
  --format both

if errorlevel 1 (
    echo.
    echo [错误] 分析过程中出现错误
    pause
    exit /b 1
)

echo.
echo ========================================
echo 分析完成！
echo ========================================
echo.
echo 报告文件位置: %OUTPUT_PATH%
echo.
echo 按任意键查看生成的报告...
pause

REM 打开输出目录
explorer "%OUTPUT_PATH%"

exit /b 0
