# SpringBoot + Vue 全链路静态分析工具 - 使用说明书

## 📖 目录

1. [工具概述](#工具概述)
2. [环境要求](#环境要求)
3. [安装步骤](#安装步骤)
4. [快速开始](#快速开始)
5. [详细配置](#详细配置)
6. [输出说明](#输出说明)
7. [实战案例](#实战案例)
8. [常见问题](#常见问题)

---

## 工具概述

### 功能简介

本工具是一款专业的 **SpringBoot + Vue 全链路静态分析工具**，专为数币工程等复杂企业级应用设计。通过自动扫描源代码，生成从前端到数据库的完整调用链路报告，帮助开发团队进行：

- ✅ **需求影响性分析** - 评估变更影响范围
- ✅ **增量开发辅助** - 参考现有模式快速开发
- ✅ **架构文档生成** - 自动生成系统架构图谱
- ✅ **代码审计** - 发现潜在架构问题

### 核心特性

| 特性 | 说明 |
|------|------|
| 全链路追踪 | 前端组件 → API → Controller → Service → Mapper → Entity → 数据库表 |
| 智能匹配 | 支持精确匹配和模糊匹配，自动关联前后端代码 |
| 置信度评分 | 每条链路附带 0-100% 置信度，便于人工复核 |
| 多格式输出 | 支持 JSON（程序化）和 Markdown（可读性）两种格式 |
| 零依赖 | 仅使用 Python 标准库，无需安装额外包 |

### 支持的注解和技术栈

**后端 (SpringBoot)**:
- `@RestController`, `@Controller`
- `@GetMapping`, `@PostMapping`, `@PutMapping`, `@DeleteMapping`, `@RequestMapping`
- `@Service`, `@Transactional`
- `@Mapper`, `@Repository`
- `@Entity`, `@Table`, `@Column`, `@Id`
- `@Autowired`, `@Resource`
- MyBatis XML

**前端 (Vue)**:
- `.vue` 单文件组件
- axios 直接调用
- API 模块封装调用
- TypeScript/JavaScript

---

## 环境要求

### 硬件要求
- CPU: 双核以上
- 内存: 2GB 以上（大型项目建议 4GB+）
- 磁盘: 至少 100MB 可用空间

### 软件要求
- **操作系统**: Windows 10/11, Linux, macOS
- **Python**: 3.12 - 3.14（推荐 3.12）
- **项目类型**: SpringBoot + Vue 项目

### 验证 Python 环境

打开命令提示符或终端，执行：
```bash
python --version
```

应显示类似：
```
Python 3.12.10
```

如果未安装 Python，请访问 https://www.python.org/downloads/ 下载安装。

---

## 安装步骤

### 步骤 1: 下载工具文件

将以下文件保存到本地目录（例如 `E:\tools\`）：

1. **fullchain_analyzer.py** - 主程序（约 40KB，1038 行）
2. **run_analysis.bat** - Windows 批处理启动脚本（可选）
3. **README_WINDOWS.md** - 快速参考指南（可选）

### 步骤 2: 确认项目结构

确保您的项目符合标准 SpringBoot + Vue 结构：

**后端目录示例**:
```
E:\workspace-analysis\AI4DC\05 源码\backend\
├── src\
│   └── main\
│       ├── java\com\example\
│       │   ├── controller\UserController.java
│       │   ├── service\impl\UserServiceImpl.java
│       │   ├── mapper\UserMapper.java
│       │   └── entity\User.java
│       └── resources\
│           ├── application.properties
│           └── mapper\UserMapper.xml
```

**前端目录示例**:
```
E:\workspace-analysis\AI4DC\05 源码\frontend\
├── src\
│   ├── views\user\UserList.vue
│   ├── components\user\UserForm.vue
│   └── api\user.js
```

### 步骤 3: 配置路径

编辑 `run_analysis.bat` 文件，修改以下配置：

```batch
SET BACKEND_PATH=E:\workspace-analysis\AI4DC\05 源码\backend
SET FRONTEND_PATH=E:\workspace-analysis\AI4DC\05 源码\frontend
SET OUTPUT_PATH=E:\workspace-analysis\AI4DC\05 源码\analysis_output
SET PROJECT_NAME=数币工程
SET TOOL_PATH=E:\tools\fullchain_analyzer.py
```

---

## 快速开始

### 方法一：使用批处理脚本（推荐 Windows 用户）

1. 双击运行 `run_analysis.bat`
2. 等待分析完成
3. 查看输出目录中的报告文件

### 方法二：命令行直接执行

打开命令提示符，执行：

```cmd
cd E:\tools

python fullchain_analyzer.py ^
  -b "E:\workspace-analysis\AI4DC\05 源码\backend" ^
  -f "E:\workspace-analysis\AI4DC\05 源码\frontend" ^
  -o "E:\workspace-analysis\AI4DC\05 源码\analysis_output" ^
  -p "数币工程" ^
  -fmt both
```

### 方法三：PowerShell 执行

```powershell
python fullchain_analyzer.py `
  --backend "E:\workspace-analysis\AI4DC\05 源码\backend" `
  --frontend "E:\workspace-analysis\AI4DC\05 源码\frontend" `
  --output "E:\workspace-analysis\AI4DC\05 源码\analysis_output" `
  --project-name "数币工程" `
  --format both
```

---

## 详细配置

### 命令行参数

| 参数 | 简写 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|------|--------|------|
| --backend | -b | 路径 | ✅ | 无 | SpringBoot 后端项目根目录 |
| --frontend | -f | 路径 | ✅ | 无 | Vue 前端项目根目录 |
| --output | -o | 路径 | ❌ | ./analysis_output | 输出报告目录 |
| --format | -fmt | 选项 | ❌ | both | 输出格式：json / md / both |
| --project-name | -p | 文本 | ❌ | 未命名项目 | 项目名称 |

### 输出格式说明

- **json**: 生成结构化 JSON 文件，适合程序处理和二次开发
- **md**: 生成 Markdown 文档，适合人工阅读和汇报
- **both**: 同时生成两种格式（推荐）

### 高级用法

#### 仅分析后端
```cmd
python fullchain_analyzer.py -b ./backend -f ./dummy -fmt json
```

#### 自定义输出文件名
```cmd
python fullchain_analyzer.py -b ./backend -f ./frontend -o ./reports/report_2024.json
```

#### 批量分析多个项目
创建批处理文件循环执行：
```batch
for %%d in (project1 project2 project3) do (
    python fullchain_analyzer.py -b ./%%d/backend -f ./%%d/frontend -o ./output/%%d
)
```

---

## 输出说明

### 输出文件列表

分析完成后，输出目录包含：

```
analysis_output/
├── fullchain_analysis_20240416_143025.json   # JSON 报告
└── fullchain_analysis_20240416_143025.md     # Markdown 报告
```

### JSON 报告结构

```json
{
  "project_name": "数币工程",
  "analysis_time": "2024-04-16T14:30:25",
  "backend_path": "E:\\...\\backend",
  "frontend_path": "E:\\...\\frontend",
  "data_source": {
    "url": "jdbc:mysql://localhost:3306/digital_currency",
    "username": "root",
    "driver_class": "com.mysql.cj.jdbc.Driver",
    "database": "digital_currency"
  },
  "controllers": [...],
  "services": [...],
  "mappers": [...],
  "entities": [...],
  "vue_components": [...],
  "full_chains": [...],
  "statistics": {
    "controllers": 15,
    "services": 12,
    "mappers": 10,
    "entities": 25,
    "vue_components": 30,
    "full_chains": 45
  }
}
```

### Markdown 报告章节

1. **统计概览** - 各层组件数量统计
2. **数据源配置** - 数据库连接信息
3. **全链路追踪** - 完整的调用链路（带置信度）
4. **Controllers** - API 端点列表
5. **Services** - 业务服务列表
6. **Entities** - 实体类与表映射
7. **Vue Components** - 前端组件列表
8. **需求影响性分析指南** - 使用方法说明

### 置信度说明

| 置信度 | 标识 | 含义 | 处理建议 |
|--------|------|------|----------|
| ≥70% | ✅ | 高置信度 | 链路完整，可直接使用 |
| 50%-70% | ⚠️ | 中置信度 | 基本完整，建议复核 |
| <50% | ❓ | 低置信度 | 不完整或推测，需人工确认 |

---

## 实战案例

### 案例 1: 需求变更影响分析

**场景**: 需要修改用户管理模块的删除功能

**步骤**:
1. 打开 Markdown 报告
2. 搜索 "User" 相关链路
3. 找到对应链路：
   ```
   ### ✅ CHAIN_0005 (置信度：90.0%)
   - 前端组件：UserList.vue
     - 函数：deleteUser()
   - API: DELETE /api/user/{id}
   - Controller: UserController.deleteUser()
   - Service: UserServiceImpl.deleteUser()
   - Mapper: UserMapper.deleteById()
   - Entity: User → 表：sys_user
   ```
4. 评估影响范围：仅需修改此链路涉及的文件
5. 制定修改方案

### 案例 2: 新增功能开发

**场景**: 新增订单导出功能

**步骤**:
1. 参考现有订单相关链路模式
2. 按照现有规范新增：
   - 前端：OrderList.vue 添加 exportOrders() 函数
   - API: GET /api/order/export
   - Controller: OrderController.export()
   - Service: OrderServiceImpl.export()
   - Mapper: OrderMapper.selectAllForExport()
3. 保持命名和结构一致性

### 案例 3: 数据库表重构

**场景**: sys_user 表需要新增字段

**步骤**:
1. 在报告中查找 "sys_user" 表
2. 定位到 User 实体类
3. 查看哪些 Mapper 操作该表
4. 追溯受影响的 Service 和 Controller
5. 确认前端是否有相关展示
6. 制定完整修改计划

---

## 常见问题

### Q1: 分析结果为空怎么办？

**可能原因**:
1. 项目路径不正确
2. 项目结构不符合标准
3. 未使用标准注解

**解决方案**:
- 检查路径是否指向正确的后端/前端根目录
- 确认项目使用 @RestController、@Service 等标准注解
- 查看日志输出的详细扫描过程

### Q2: 置信度过低如何处理？

**可能原因**:
1. 前后端 API 路径命名不一致
2. Service/Mapper 命名不规范
3. 使用了非标准的依赖注入方式

**解决方案**:
- 手动核对低置信度链路
- 统一命名规范（如 Controller→Service→Mapper 的命名对应）
- 在代码中添加更明确的注解

### Q3: 如何解析 API 模块封装的调用？

**说明**: 工具会自动尝试推断 API 模块调用的实际路径，但准确率取决于命名规范性。

**优化建议**:
```javascript
// 推荐：清晰的方法名
api.getUserList()      // ✓ 易推断
api.user.list()        // ✓ 易推断
api.xxx()              // ✗ 难推断

// 可在 api/user.js 中添加注释
export function getUserList() {
  return request({ url: '/user/list', method: 'get' })
}
```

### Q4: 大型项目分析很慢怎么办？

**优化建议**:
1. 关闭其他占用资源的程序
2. 使用 SSD 硬盘
3. 分模块分析（将大项目拆分为多个子项目分别分析）
4. 首次分析后，后续可仅分析变更模块

### Q5: 如何集成到 CI/CD 流程？

**示例** (Jenkins Pipeline):
```groovy
pipeline {
    agent any
    stages {
        stage('架构分析') {
            steps {
                sh '''
                    python fullchain_analyzer.py \\
                      -b ./backend \\
                      -f ./frontend \\
                      -o ./reports \\
                      -fmt json
                '''
            }
            post {
                always {
                    archiveArtifacts artifacts: './reports/*.json'
                }
            }
        }
    }
}
```

---

## 附录

### A. 日志级别说明

工具运行时输出日志包含：
- **INFO**: 正常分析进度
- **WARNING**: 警告信息（如路径不存在）
- **ERROR**: 错误信息（如解析失败）

### B. 性能参考

| 项目规模 | Java 文件数 | Vue 文件数 | 分析时间 |
|----------|------------|-----------|----------|
| 小型 | <50 | <20 | <10 秒 |
| 中型 | 50-200 | 20-50 | 10-30 秒 |
| 大型 | 200-500 | 50-150 | 30-60 秒 |
| 超大型 | >500 | >150 | 1-3 分钟 |

### C. 版本历史

- **v1.0** (2024): 初始版本
  - 支持 SpringBoot + Vue 基础分析
  - 支持 JSON/Markdown 输出
  - 支持置信度评分

### D. 技术支持

如有问题，请提供：
1. Python 版本
2. 项目结构截图
3. 完整的错误日志
4. 相关代码片段（脱敏后）

---

**文档版本**: 1.0  
**最后更新**: 2024 年  
**适用工具版本**: fullchain_analyzer.py v1.0
