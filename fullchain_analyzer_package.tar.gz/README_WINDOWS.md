# SpringBoot + Vue 全链路静态分析工具 - Windows 使用指南

## 📋 工具说明

本工具用于对 SpringBoot + Vue 项目进行全链路静态分析，生成从前端到数据库的完整调用链路报告，支持需求影响性分析和增量开发辅助。

**支持版本**: Python 3.12 - 3.14  
**兼容系统**: Windows 10/11, Linux, macOS

---

## 🚀 快速开始

### 步骤 1: 下载工具

将 `fullchain_analyzer.py` 文件保存到本地，例如：
```
E:\tools\fullchain_analyzer.py
```

### 步骤 2: 确认 Python 环境

打开命令提示符 (CMD) 或 PowerShell，验证 Python 版本：
```cmd
python --version
```
应显示 Python 3.12.x 或 Python 3.14.x

### 步骤 3: 运行分析

针对您的数币工程，执行以下命令：

```cmd
cd E:\tools

python fullchain_analyzer.py ^
  --backend "E:\workspace-analysis\AI4DC\05 源码\backend" ^
  --frontend "E:\workspace-analysis\AI4DC\05 源码\frontend" ^
  --output "E:\workspace-analysis\AI4DC\05 源码\analysis_output" ^
  --project-name "数币工程" ^
  --format both
```

> **注意**: 
> - 请将 `backend` 和 `frontend` 替换为实际的后端和前端目录路径
> - 如果项目结构不同，请相应调整路径

---

## 📁 目录结构要求

### 后端项目结构 (SpringBoot)
```
backend/
├── src/
│   └── main/
│       ├── java/
│       │   └── com/
│       │       └── example/
│       │           ├── controller/     # Controller 层
│       │           ├── service/        # Service 层
│       │           ├── mapper/         # Mapper/DAO 层
│       │           └── entity/         # Entity 实体类
│       └── resources/
│           ├── application.properties  # 或 application.yml
│           └── mapper/                 # MyBatis XML (可选)
```

### 前端项目结构 (Vue)
```
frontend/
├── src/
│   ├── views/              # 页面组件
│   │   └── *.vue
│   ├── components/         # 公共组件
│   │   └── *.vue
│   └── api/                # API 模块 (可选)
│       └── *.js
```

---

## 🔧 命令行参数说明

| 参数 | 简写 | 必填 | 说明 | 示例 |
|------|------|------|------|------|
| --backend | -b | ✅ | SpringBoot 后端项目根目录 | `E:\project\backend` |
| --frontend | -f | ✅ | Vue 前端项目根目录 | `E:\project\frontend` |
| --output | -o | ❌ | 输出报告目录 | `E:\analysis_output` |
| --format | -fmt | ❌ | 输出格式 (json/md/both) | `both` |
| --project-name | -p | ❌ | 项目名称 | `数币工程` |

---

## 📊 输出文件说明

分析完成后，在输出目录会生成以下文件：

### 1. JSON 报告 (`fullchain_analysis_YYYYMMDD_HHMMSS.json`)
- 完整的结构化数据
- 可用于程序化处理和二次开发
- 包含所有分析细节

### 2. Markdown 报告 (`fullchain_analysis_YYYYMMDD_HHMMSS.md`)
- 人类可读的分析报告
- 包含统计概览、全链路追踪、影响性分析指南
- 可直接用浏览器或 Markdown 编辑器查看

---

## 📈 分析报告内容

### 统计概览
- Controllers 数量
- Services 数量
- Mappers 数量
- Entities 数量
- Vue Components 数量
- 完整链路数量

### 全链路追踪
每条链路包含：
- 前端组件及函数
- API 请求方法和路径
- Controller 类和方法
- Service 类和方法
- Mapper 类和方法
- Entity 类和数据库表
- 置信度评分 (0-100%)

### 需求影响性分析指南
1. **前端变更影响分析**
2. **后端变更影响分析**
3. **数据库变更影响分析**
4. **增量开发辅助**
5. **置信度说明**

---

## 💡 使用示例

### 示例 1: 基本用法
```cmd
python fullchain_analyzer.py -b E:\project\backend -f E:\project\frontend
```

### 示例 2: 指定所有参数
```cmd
python fullchain_analyzer.py ^
  -b E:\workspace-analysis\AI4DC\05 源码\backend ^
  -f E:\workspace-analysis\AI4DC\05 源码\frontend ^
  -o E:\workspace-analysis\AI4DC\05 源码\reports ^
  -p 数币工程 ^
  -fmt both
```

### 示例 3: 仅生成 JSON
```cmd
python fullchain_analyzer.py -b ./backend -f ./frontend -fmt json
```

---

## 🔍 分析能力

### 后端分析
- ✅ 识别 `@RestController`, `@Controller`
- ✅ 提取 API 端点 (`@GetMapping`, `@PostMapping` 等)
- ✅ 识别 `@Service` 和业务方法
- ✅ 识别 `@Mapper`, `@Repository`
- ✅ 识别 `@Entity`, `@Table` 和字段映射
- ✅ 解析 `application.properties/yml` 数据源配置
- ✅ 支持 MyBatis XML 查找

### 前端分析
- ✅ 识别 `.vue` 组件
- ✅ 提取直接 axios 调用
- ✅ 提取 API 模块调用
- ✅ 推断 API 路径
- ✅ 提取组件函数

### 链路构建
- ✅ 前后端 API 匹配
- ✅ 模糊路径匹配
- ✅ 服务层依赖追踪
- ✅ 实体类与表关联
- ✅ 置信度评分

---

## ⚠️ 注意事项

1. **编码问题**: 确保源代码文件使用 UTF-8 编码
2. **路径问题**: Windows 路径包含空格时需用双引号包裹
3. **权限问题**: 确保对输入输出目录有读写权限
4. **大项目**: 大型项目分析可能需要几分钟，请耐心等待
5. **置信度**: 低置信度链路需人工确认

---

## 🛠️ 故障排除

### 问题 1: "python 不是内部或外部命令"
**解决**: 
- 确认已安装 Python
- 将 Python 添加到系统 PATH 环境变量
- 或使用完整路径：`C:\Python312\python.exe`

### 问题 2: "模块未找到"
**解决**: 
- 本工具仅使用标准库，无需额外安装
- 确认下载的是完整版 `fullchain_analyzer.py`

### 问题 3: "路径不存在"
**解决**:
- 检查路径是否正确
- 确认路径中包含实际的 SpringBoot/Vue 项目
- 使用绝对路径而非相对路径

### 问题 4: 分析结果为空
**解决**:
- 确认项目结构符合标准 SpringBoot/Vue 布局
- 检查是否使用了标准注解 (@RestController, @Service 等)
- 查看日志输出了解详细扫描过程

---

## 📞 技术支持

如遇到问题，请检查：
1. Python 版本是否为 3.12-3.14
2. 项目路径是否正确
3. 项目结构是否符合要求
4. 日志输出的详细信息

---

## 📝 许可证

本工具仅供内部使用，用于架构分析和需求影响性评估。

**版本**: 1.0  
**更新日期**: 2024
